<?php
	require_once "Models/Conexao.class.php";
	require_once "Models/categoriaDAO.class.php";
	require_once "Models/Categoria.class.php";
	class categoriaController
	{
		public function listar()
		{
			//buscar os dados no banco
			$categoriaDAO = new categoriaDAO();
			$retorno = $categoriaDAO->buscar_todas();
			require_once "views/listar_categorias.php";
			//mostra a view
		}//fim do método listar
		public function inserir()
		{
			$erro = "";
			if($_POST)
			{
				//verificar se descrição preenchida
				if(empty($_POST["descritivo"]))
				{
					$erro = "Preencha o descritivo";
				}
				else
				{
					//inserir a nova categoria no bd
					$categoria = new Categoria(0,$_POST["descritivo"]);
					
					$categoriaDAO = new categoriaDAO();
					$retorno = $categoriaDAO->inserir($categoria);
					header("location:index.php?controle=categoriaController&metodo=listar&msg=$retorno");
				}
			}
			require_once "Views/form_categoria.php";
		}
	}//fim da classe
?>