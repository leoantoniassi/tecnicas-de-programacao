<?php
	class produtoController
	{
		public function listar()
		{
			echo "Estou no listar do produto";
		}
	}
?>