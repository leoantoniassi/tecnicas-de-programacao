<?php
	require_once "header.php";
?>
	<div class="content">
	<div class="container">
	<br>
		<h1>Categoria</h1>
	<br>
		<form action="/loja/alterar" method="post">
		
			<input type="hidden" name="idcategoria" value="<?php echo $retorno[0]->idcategoria; ?>">
			
			<label for="descritivo">Descritivo:</label>
			<input type="text" name="descritivo" id="descritivo" value="<?php echo $retorno[0]->descritivo;?>">
			<div style="color:red;font-size:12px;"><?php echo isset($_GET['erro'])?$_GET['erro']:'';?></div>
			<br><br>
			<input type="submit" value="Alterar">
		</form>
	</div>
	</div>
<?php
	require_once "footer.html";
?>