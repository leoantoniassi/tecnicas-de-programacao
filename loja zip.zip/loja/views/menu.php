<?php
	require_once "cabecalho.php";
?>
		
	</body>
</html>